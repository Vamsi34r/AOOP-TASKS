package task_1;

public interface PowerUp {
    void activate();
    void display();
}
