package task_1;

public class Sword implements Weapon {
    public void use() {
        System.out.println("Swinging a sword!");
    }

    public void display() {
        System.out.println("A Sword has been equipped!");
    }
}
