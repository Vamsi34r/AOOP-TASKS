package task_1;

public interface Weapon {
    void use();
    void display();
}
