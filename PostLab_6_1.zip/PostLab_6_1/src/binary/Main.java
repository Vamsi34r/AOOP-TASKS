package binary;

public class Main {
    public static void main(String[] args) {
        Integer[] intArray = {1, 2, 3, 4, 5, 6, 7, 8, 9};
        BinarySearch<Integer> intSearch = new BinarySearch<>();
        int intResult = intSearch.binarySearch(intArray, 5);
        System.out.println("Integer search result: " + (intResult >= 0 ? "Found at index " + intResult : "Not found"));

        Double[] doubleArray = {1.1, 2.2, 3.3, 4.4, 5.5};
        BinarySearch<Double> doubleSearch = new BinarySearch<>();
        int doubleResult = doubleSearch.binarySearch(doubleArray, 3.3);
        System.out.println("Double search result: " + (doubleResult >= 0 ? "Found at index " + doubleResult : "Not found"));

        String[] strArray = {"apple", "banana", "cherry", "date", "elderberry"};
        BinarySearch<String> strSearch = new BinarySearch<>();
        int strResult = strSearch.binarySearch(strArray, "cherry");
        System.out.println("String search result: " + (strResult >= 0 ? "Found at index " + strResult : "Not found"));
    }
}

